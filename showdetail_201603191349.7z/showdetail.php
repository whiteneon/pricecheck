<?php
setlocale(LC_MONETARY, 'en_US');
$conn = mysqli_connect('localhost', 'workorder', 'workorder', 'workorder', '3306');
if (!$conn) {
	die('Could not connect to MySQL: ' . mysqli_connect_error());
}
$sku = $_REQUEST["sku"];
$store = '1';
$len = strlen($sku);
$hint = "";
$sep = "---";
if ($len > 2) {
	$sku = strtoupper($sku);
	

	$select = "SELECT * FROM  `parts` WHERE  `SKU` LIKE  '$sku' AND `Store` = '$store'";

	$result = mysqli_query($conn, $select);
	//$end_time = microtime();
	$rowcount = mysqli_num_rows($result);
	//$hint = 'SKU'. $sep . 'Desc' . $sep . 'Dept' . $sep . '$KY' . $sep . '$OOS<BR>' . "\n";
	while (($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) != NULL) {
		?><html><head><title>Cox Interior SKU Info</title></head><body><?php
		//$hint .= $row['SKU'] . $sep . $row['Description'] . $sep . $row['Dept'] . $sep . '$' . number_format($row['Price1'], 2, ".", ",") .
		//$sep . '$' . number_format($row['Price5'], 2, ".", ",") . "<BR>\n";
		$hint = '<font color="purple">Store: ' . $row['Store'] . '</font><BR>' .
				'<font color="red">' . $row['SKU'] . '</font>' . "<BR>\n" . $row['Description'] . "<BR>\n" .
				"Dept:" . $row['Dept'] . "<BR>\n" .
				"KY " . '$' . number_format($row['Price1'], 2, ".", ",") . "<BR>\n" .
				"Dealer " . '$' . number_format($row['Price2'], 2, ".", ",") . "<BR>\n" .
				"OOS " . '$' . number_format($row['Price5'], 2, ".", ",") . "<BR>\n" . 
				"Qty Avail." . $row['QtyAvail'] . "<BR>" .
				"Avg Mnthly Sales: " . $row['SalesAvg'] . "<BR>";
		?></body></html><?php
	}
	//$hint = "$rowcount results found!\n";

	
} else {
	
}
echo $hint === "" ? "no suggestion" : $hint;
exit();

// get the q parameter from URL
$q = $_REQUEST["q"];

$hint = "";

// lookup all hints from array if $q is different from "" 
if ($q !== "") {
    $q = strtolower($q);
    $len=strlen($q);
    foreach($a as $name) {
        if (stristr($q, substr($name, 0, $len))) {
            if ($hint === "") {
                $hint = $name;
            } else {
                $hint .= ", $name";
            }
        }
    }
}

// Output "no suggestion" if no hint was found or output correct values 
echo $hint === "" ? "no suggestion" : $hint;
?>